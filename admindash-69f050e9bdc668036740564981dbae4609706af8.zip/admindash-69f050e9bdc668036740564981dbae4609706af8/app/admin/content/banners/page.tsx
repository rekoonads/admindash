"use client"

import { BannerManager } from "@/components/banner-manager"

export default function BannersPage() {
  return <BannerManager />
}