"use client"
import { ResizablePanelGroup, ResizablePanel, ResizableHandle } from "react-resizable-panels"

export { ResizablePanelGroup, ResizablePanel, ResizableHandle }
